# Sticky-Notes
Stick Notes PHP website. Written in 2015 for my first PHP course at Dawson College. 
I have not modified the code since it was submitted in 2015.

This is a very simple Sticky Notes PHP website. It uses a MySQL database to store user login and sticky note information. 
Usernames and hashed passwords are stored in one table. Sticky note text, coordinates and user id are stored in another table.
Sticky notes can be easily created, moved and deleted on the Dashboard page without page refreshes using ajax calls. 

## Login Page ##
![Login Page](https://i.imgur.com/4pVabQ6.png)
The login page was not made by me. See license.txt

## Sticky Notes Dashboard ##
![Dashboard](https://i.imgur.com/OtqJR2o.png)

The sticky.sql script must be executed on the MySQL database for the website to run properly.